SET SERVEROUTPUT ON

DECLARE

    -- Cursor spc(SAC Produto Cliente) para exibir as informa��es
    CURSOR spc_cursor IS
    SELECT
    S.nr_sac, S.dt_abertura_sac, S.hr_abertura_sac, S.tp_sac,
    P.cd_produto, P.ds_produto, P.vl_unitario, P.vl_perc_lucro,
    C.nr_cliente, C.nm_cliente,
    (P.vl_perc_lucro / 100) * P.vl_unitario AS var_cal_vl_lucro_prod
    FROM MC_SGV_SAC S
    JOIN MC_PRODUTO P ON S.cd_produto = P.cd_produto
    JOIN MC_CLIENTE C ON S.nr_cliente = C.nr_cliente;
  
    -- Vari�veis para guardar os dados do cursor
    var_mc_spc spc_cursor%ROWTYPE;
    -- Vari�vel para guardar o Tipo de Sac
    var_tp_class_sac VARCHAR2(20);
    -- Vari�vel para guardar o valor de lucro unit�rio
    var_cal_vl_lucro_prod NUMBER(8,2);
    -- Vari�veis nome e sigla estado
    var_sg_estado MC_ESTADO.SG_ESTADO%TYPE;
    var_nm_estado MC_ESTADO.NM_ESTADO%TYPE;
    -- Vari�vel para c�lculo do ICMS
    var_icms_estado NUMBER(10,2);


BEGIN    
    -- Abrir cursor
    OPEN spc_cursor;

    -- LOOP
    LOOP
        FETCH spc_cursor INTO var_mc_spc;
               
        -- Sair do loop quando n�o houver registros
        EXIT WHEN spc_cursor%NOTFOUND;
        
        -- Consulta para pegar os estados
        SELECT E.sg_estado, E.nm_estado
        INTO var_sg_estado, var_nm_estado
        FROM MC_END_CLI EC
        JOIN MC_LOGRADOURO L ON EC.cd_logradouro_cli = L.cd_logradouro
        JOIN MC_BAIRRO B ON L.cd_bairro = B.cd_bairro
        JOIN MC_CIDADE CI ON B.cd_cidade = CI.cd_cidade
        JOIN MC_ESTADO E ON CI.sg_estado = E.sg_estado
        WHERE EC.NR_CLIENTE = var_mc_spc.nr_cliente
        FETCH FIRST 1 ROW ONLY;
        
        -- Pegando a fun��o ICMS disponibilizada pela FIAP
        var_icms_estado := pf0110.fun_mc_gera_aliquota_media_icms_estado(var_sg_estado);
        
        -- Calculando o ICMS
        var_icms_estado := (var_icms_estado / 100) * var_mc_spc.vl_unitario;
        
        -- Case para tomada de decis�o do Tipo de Sac
        CASE var_mc_spc.tp_sac
            WHEN 'S' THEN var_tp_class_sac := 'SUGEST�O';
            WHEN 'D' THEN var_tp_class_sac := 'D�VIDA';
            WHEN 'E' THEN var_tp_class_sac := 'ELOGIO';
            ELSE var_tp_class_sac := 'CLASSIFICA��O INV�LIDA';
        END CASE;
        
        INSERT INTO MC_SGV_OCORRENCIA_SAC (
        NR_OCORRENCIA_SAC, DT_ABERTURA_SAC,HR_ABERTURA_SAC,
        DS_TIPO_CLASSIFICACAO_SAC, DS_INDICE_SATISFACAO_ATD_SAC, CD_PRODUTO,
        DS_PRODUTO, VL_UNITARIO_PRODUTO, VL_PERC_LUCRO, VL_UNITARIO_LUCRO_PRODUTO,
        SG_ESTADO, NM_ESTADO, NR_CLIENTE, NM_CLIENTE, VL_ICMS_PRODUTO)
        VALUES (
        var_mc_spc.nr_sac, var_mc_spc.dt_abertura_sac, var_mc_spc.hr_abertura_sac, var_tp_class_sac, '',
        var_mc_spc.cd_produto, var_mc_spc.ds_produto, var_mc_spc.vl_unitario,
        var_mc_spc.vl_perc_lucro, var_mc_spc.var_cal_vl_lucro_prod, var_sg_estado,
        var_nm_estado, var_mc_spc.nr_cliente, var_mc_spc.nm_cliente, var_icms_estado);

        -- Painel de exibi��o
        DBMS_OUTPUT.PUT_LINE('-----Painel Ocorr�ncias-----------');
        DBMS_OUTPUT.PUT_LINE('N�mero da ocorr�ncia do SAC: ' || var_mc_spc.nr_sac);
        DBMS_OUTPUT.PUT_LINE('Data de abertura do SAC: ' || var_mc_spc.dt_abertura_sac);
        DBMS_OUTPUT.PUT_LINE('Hora de abertura do SAC: ' || var_mc_spc.hr_abertura_sac);
        DBMS_OUTPUT.PUT_LINE('Tipo do SAC: ' || var_tp_class_sac);
        DBMS_OUTPUT.PUT_LINE('C�digo do produto: ' || var_mc_spc.cd_produto);
        DBMS_OUTPUT.PUT_LINE('Nome do produto: ' || var_mc_spc.ds_produto);
        DBMS_OUTPUT.PUT_LINE('Valor unit�rio do produto: ' || var_mc_spc.vl_unitario);
        DBMS_OUTPUT.PUT_LINE('Percentual do lucro unit�rio do produto: ' || ROUND(var_mc_spc.var_cal_vl_lucro_prod, 2));
        DBMS_OUTPUT.PUT_LINE('N�mero do Cliente: ' || var_mc_spc.nr_cliente);
        DBMS_OUTPUT.PUT_LINE('Nome do Cliente: ' || var_mc_spc.nm_cliente);
        DBMS_OUTPUT.PUT_LINE('Estado: ' || var_sg_estado);
        DBMS_OUTPUT.PUT_LINE('Nome do Estado: ' || var_nm_estado);
        DBMS_OUTPUT.PUT_LINE('Valor ICMS: ' || var_icms_estado);
        DBMS_OUTPUT.PUT_LINE('---------------------------------');
        DBMS_OUTPUT.PUT_LINE('');

END LOOP;   
CLOSE spc_cursor;
END;
/